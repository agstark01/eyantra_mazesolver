module top_ultrasonic(
	 input clk_50M, reset, echo_rx1, echo_rx2, echo_rx3,
    output trig1,
	 output trig2,
	 output trig3,
    output op1,
	 output op2,
	 output op3,
    //output [1:0] curr,
    output wire [15:0] dis_stable1, 
	 output wire [15:0]dis_stable2,
	 output wire [15:0]dis_stable3,
	 output motor_pwm1,
	 output motor_pwm2,
	 output IN1,IN2,IN3,IN4
);

    wire [15:0] distance_out1; 
	 wire [15:0]distance_out2;
	 wire [15:0]distance_out3;

	
t1b_ultrasonic #(.MIN_DIST_MM(70)) sensor1 (
		.clk_50M(clk_50M),
		.echo_rx(echo_rx1),
		.reset(reset),
		.trig(trig1),
		.op(op1),
		.distance_out(distance_out1)
);

t1b_ultrasonic  #(.MIN_DIST_MM(70)) sensor2(
		.clk_50M(clk_50M),
		.echo_rx(echo_rx2),
		.reset(reset),
		.trig(trig2),
		.op(op2),
		.distance_out(distance_out2)
);

t1b_ultrasonic #(.MIN_DIST_MM(70)) sensor3 (
		.clk_50M(clk_50M),
		.echo_rx(echo_rx3),
		.reset(reset),
		.trig(trig3),
		.op(op3),
		.distance_out(distance_out3)
);


	moving_average m1(.clk_50M(clk_50M),.reset(reset),.dis_in(distance_out1), .dis_out(dis_stable1));
	moving_average m2(.clk_50M(clk_50M),.reset(reset),.dis_in(distance_out2), .dis_out(dis_stable2));
	moving_average m3(.clk_50M(clk_50M),.reset(reset),.dis_in(distance_out3), .dis_out(dis_stable3));
	
//	lk_50M,
//	duty_cycle,
//	pwm_signal,
//	clk_195KHz,
//	clk_3125KHz
	
	parameter expected = 70;
	reg [7:0] error_val1;
	//assign error_val1 = dis_stable2 - expected;
	
	reg [7:0] error_val2;
	//assign error_val2 =  dis_stable3 - expected;
	
//	assign motor_pwm1 = 0;
//	assign motor_pwm2 = 0;
	
	always @(posedge clk_50M, negedge reset) begin
		if(!reset)begin
			error_val1 <= 0;
			error_val2 <= 0;
		end else begin
			if(dis_stable2 <= 100 && dis_stable3 <= 100) begin
				if(dis_stable2 > dis_stable3)begin
					error_val1 <= 128+ (dis_stable2 - dis_stable3)/2;
					error_val2 <= 128 - (dis_stable2 - dis_stable3)/2 ;
				end else if( dis_stable2 < dis_stable3) begin
					error_val1 <= 128 - (dis_stable3 - dis_stable2)/2;
					error_val2 <= 128 + (dis_stable3 - dis_stable2)/2;
				end else begin
					error_val1 <= 128 ;
					error_val2 <= 128;
				end
			end else begin
				if( dis_stable2 > dis_stable3)begin
					error_val1 <= 128;
					error_val2 <= 42;
				end else begin
					error_val1 <= 42;
					error_val2 <= 128;
				end
			end
		end
	
	end
	
	t1a_fs_pwm_bdf pwm1(.clk_50M(clk_50M),.duty_cycle(error_val1),.pwm_signal(motor_pwm1));
	t1a_fs_pwm_bdf pwm2(.clk_50M(clk_50M),.duty_cycle(error_val2),.pwm_signal(motor_pwm2));
	
	assign {IN1,IN2,IN3,IN4} = 4'b1010;
	
	
endmodule